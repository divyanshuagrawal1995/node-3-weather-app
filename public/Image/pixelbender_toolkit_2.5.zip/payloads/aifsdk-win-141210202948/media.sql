CREATE TABLE Branding ( ProductID TEXT NOT NULL REFERENCES Suites (ProductID),resource_type TEXT NOT NULL,resource_data TEXT NOT NULL,PRIMARY KEY (ProductID, resource_type) )
CREATE TABLE DependencyData( PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),PayloadIDb TEXT ,type TEXT NOT NULL ,product_family TEXT, product_name TEXT, version TEXT, PRIMARY KEY (PayloadID,PayloadIDb,type,product_family,product_name,version))
CREATE TABLE EULA_Files( productID TEXT NOT NULL, langCode TEXT NOT NULL,eula TEXT NOT NULL,PRIMARY KEY (productID, langCode) )
CREATE TABLE PayloadData( PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),domain TEXT NOT NULL,key TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY (PayloadID, domain, key) )
CREATE TABLE Payloads( PayloadID TEXT NOT NULL, payload_family TEXT NOT NULL,payload_name TEXT NOT NULL, payload_version TEXT NOT NULL,payload_type TEXT NOT NULL,PRIMARY KEY (PayloadID) )
CREATE TABLE SuitePayloads( ProductID TEXT NOT NULL REFERENCES Suites (ProductID),PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),PRIMARY KEY (ProductID, PayloadID) )
CREATE TABLE Suites( ProductID TEXT NOT NULL, group_name TEXT NOT NULL, group_family TEXT NOT NULL, display_name TEXT NOT NULL, PRIMARY KEY (ProductID) )
INSERT INTO DependencyData VALUES	("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "{8A6B041F-3B28-459E-B248-A87A0A253A6B}", "upgrade", "", "", "")
INSERT INTO DependencyData VALUES	("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "{83BBDBCE-9BC6-4343-983C-8E827EBAAE8B}", "upgrade", "", "", "")
INSERT INTO DependencyData VALUES	("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "{D5CC77BE-BC5B-424E-8E45-DF60AFF7BE9C}", "patch", "CoreTech", "Pixel Bender Toolkit", "")
INSERT INTO Payloads VALUES	("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "CoreTech", "Pixel Bender Toolkit_2.5_aifsdk-win", "2.5", "patch")
INSERT INTO PayloadData VALUES("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "0" , "PayloadInfo", '<PayloadInfo version="3.0.124.0"><BuildInfo>
    <Property name="Created">2010-12-14 20:29:48.998000</Property>
    <Property name="TargetName">aifsdk-win-141210202948</Property>
    <Property name="ProcessorFamily">All</Property>
  </BuildInfo><InstallerProperties>
    <Property name="payloadType">SQLite</Property>
    <Property name="AdobeCode">{A1CABA8D-CF84-402F-8948-D2567915D40C}</Property>
    <Property name="ProductName">Adobe Pixel Bender Toolkit 2</Property>
    <Property name="ProductVersion">2.5</Property>
  </InstallerProperties><InstallDir>
    <Platform isFixed="0" name="Default" folderName="">[AdobeProgramFiles]/Adobe Utilities - CS5/Pixel Bender Toolkit 2</Platform>
  </InstallDir><Languages languageIndependent="1"/><Satisfies>
    <ProductInfo>
      <Family>CoreTech</Family>
      <ProductName>Pixel Bender Toolkit_2.5_aifsdk-win</ProductName>
      <ProductVersion>2.5</ProductVersion>
    </ProductInfo>
  </Satisfies><Upgrades>
    <AdobeCode>{8A6B041F-3B28-459E-B248-A87A0A253A6B}</AdobeCode>
    <AdobeCode>{83BBDBCE-9BC6-4343-983C-8E827EBAAE8B}</AdobeCode>
  </Upgrades><Channel enable="1" id="AdobePixelBenderToolkit2-2.0">
        <DisplayName>Adobe Pixel Bender Toolkit 2</DisplayName>
      </Channel><Update id="2.5.1">
					<DisplayName default="en_US">
							<en_US>Adobe Pixel Bender Toolkit 2.5.1</en_US>
					</DisplayName>
					<Description default="en_US">
							<en_US>This update includes fixes some important bugs.</en_US>
					</Description>
			</Update><Extends type="patch">
    <ParentProductInfo>
      <Family>CoreTech</Family>
      <ProductName>Pixel Bender Toolkit</ProductName>
      <AdobeCode>{D5CC77BE-BC5B-424E-8E45-DF60AFF7BE9C}</AdobeCode>
    </ParentProductInfo>
  </Extends><InstallDestinationMetadata relocatableSize="2010977" sysDriveSize="37231120"><Destination>
      <Root>[AdobeProgramFiles]</Root>
      <TotalSize>37231120</TotalSize>
      <MaxPathComponent>/Adobe Utilities - CS5/Pixel Bender Toolkit 2/pixel bender files/notFlashCompatible\checkerboard.pbk</MaxPathComponent>
    </Destination>
    <Destination>
      <Root>[INSTALLDIR]</Root>
      <TotalSize>2010977</TotalSize>
      <MaxPathComponent>/Adobe/AdobePatchFiles/{A1CABA8D-CF84-402F-8948-D2567915D40C}\be459f11a8de2b308e501f08afab33c7.rtp</MaxPathComponent>
    </Destination>
    <Assets>
      <Asset flag="0" name="Assets2_1" size="37231120"/>
      <Asset flag="1" name="Assets1_1" size="2010977"/>
    </Assets>
  </InstallDestinationMetadata><ConflictingProcesses>
    <Win32>
      <Process processType="Adobe" blocking="1">^[Pp]ixel[_ ][Bb]ender[_ ][Tt]oolkit.[Ee][Xx][Ee]$</Process>
    </Win32>
  </ConflictingProcesses><AddRemoveInfo>
    <DisplayVersion>
      <Value lang="sq_AL">2.5</Value>
      <Value lang="ar_AE">2.5</Value>
      <Value lang="be_BY">2.5</Value>
      <Value lang="bg_BG">2.5</Value>
      <Value lang="ca_ES">2.5</Value>
      <Value lang="zh_CN">2.5</Value>
      <Value lang="zh_TW">2.5</Value>
      <Value lang="hr_HR">2.5</Value>
      <Value lang="cs_CZ">2.5</Value>
      <Value lang="da_DK">2.5</Value>
      <Value lang="nl_NL">2.5</Value>
      <Value lang="en_XC">2.5</Value>
      <Value lang="en_XM">2.5</Value>
      <Value lang="en_GB">2.5</Value>
      <Value lang="en_US">2.5</Value>
      <Value lang="et_EE">2.5</Value>
      <Value lang="fi_FI">2.5</Value>
      <Value lang="fr_FR">2.5</Value>
      <Value lang="fr_XM">2.5</Value>
      <Value lang="de_DE">2.5</Value>
      <Value lang="el_GR">2.5</Value>
      <Value lang="he_IL">2.5</Value>
      <Value lang="hu_HU">2.5</Value>
      <Value lang="hi_IN">2.5</Value>
      <Value lang="is_IS">2.5</Value>
      <Value lang="it_IT">2.5</Value>
      <Value lang="ja_JP">2.5</Value>
      <Value lang="ko_KR">2.5</Value>
      <Value lang="lv_LV">2.5</Value>
      <Value lang="lt_LT">2.5</Value>
      <Value lang="mk_MK">2.5</Value>
      <Value lang="nn_NO">2.5</Value>
      <Value lang="no_NO">2.5</Value>
      <Value lang="nb_NO">2.5</Value>
      <Value lang="pl_PL">2.5</Value>
      <Value lang="pt_BR">2.5</Value>
      <Value lang="ro_RO">2.5</Value>
      <Value lang="ru_RU">2.5</Value>
      <Value lang="sh_YU">2.5</Value>
      <Value lang="sk_SK">2.5</Value>
      <Value lang="sl_SI">2.5</Value>
      <Value lang="es_QM">2.5</Value>
      <Value lang="es_ES">2.5</Value>
      <Value lang="sv_SE">2.5</Value>
      <Value lang="th_TH">2.5</Value>
      <Value lang="tr_TR">2.5</Value>
      <Value lang="uk_UA">2.5</Value>
      <Value lang="vi_VN">2.5</Value>
      <Value lang="fr_CA">2.5</Value>
      <Value lang="es_MX">2.5</Value>
    </DisplayVersion>
    <DisplayName>
      <Value lang="sq_AL">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="ar_AE">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="be_BY">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="bg_BG">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="ca_ES">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="zh_CN">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="zh_TW">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="hr_HR">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="cs_CZ">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="da_DK">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="nl_NL">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="en_XC">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="en_XM">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="en_GB">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="en_US">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="et_EE">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="fi_FI">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="fr_FR">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="fr_XM">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="de_DE">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="el_GR">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="he_IL">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="hu_HU">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="hi_IN">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="is_IS">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="it_IT">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="ja_JP">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="ko_KR">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="lv_LV">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="lt_LT">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="mk_MK">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="nn_NO">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="no_NO">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="nb_NO">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="pl_PL">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="pt_BR">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="ro_RO">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="ru_RU">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="sh_YU">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="sk_SK">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="sl_SI">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="es_QM">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="es_ES">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="sv_SE">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="th_TH">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="tr_TR">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="uk_UA">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="vi_VN">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="fr_CA">Adobe Pixel Bender Toolkit 2</Value>
      <Value lang="es_MX">Adobe Pixel Bender Toolkit 2</Value>
    </DisplayName>
  </AddRemoveInfo><UserPreferences>0</UserPreferences></PayloadInfo>')
INSERT INTO PayloadData VALUES("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "0", "ChannelID", "AdobePixelBenderToolkit2-2.0")
INSERT INTO PayloadData VALUES("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "0", "ChannelInfo", '<Channel enable="1" id="AdobePixelBenderToolkit2-2.0">
        <DisplayName>Adobe Pixel Bender Toolkit 2</DisplayName>
      </Channel>')
INSERT INTO PayloadData VALUES("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "0", "UpdateID", "2.5.1")
INSERT INTO PayloadData VALUES("{A1CABA8D-CF84-402F-8948-D2567915D40C}", "0", "UpdateInfo", '<Update id="2.5.1">
					<DisplayName default="en_US">
							<en_US>Adobe Pixel Bender Toolkit 2.5.1</en_US>
					</DisplayName>
					<Description default="en_US">
							<en_US>This update includes fixes some important bugs.</en_US>
					</Description>
			</Update>')
